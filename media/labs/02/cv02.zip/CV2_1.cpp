#include "stdafx.h"
#include <windows.h>
#include <stdio.h>

using namespace std;

struct Variables {
	int a;
	char b;
	unsigned char c;
	unsigned int d;
	int opt1;
	int opt2;
	int opt3;
	int opt4;
};

void func2(Variables* v) {
	char str[256];
	DWORD numerOfBytesWritten;
	HANDLE h = CreateFile("output.txt", GENERIC_WRITE, NULL, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (h == INVALID_HANDLE_VALUE) exit(1);
	sprintf(str, "[conf]\r\nwidth=%d\r\nheight=%c\r\nXsize=%c\r\nYsize=%u\r\n[\conf]\r\n", v->a, v->b, v->c, v->d);

	WriteFile(h, str, strlen(str), &numerOfBytesWritten, NULL);
}

void func1(Variables* v) {


	int border = 6;
	if (v->a < border) {
		printf("a is smaller than %u\n", border);
	}
	else {
		printf("a is bigger than %u\n", border);
	}
	if (v->b < border) {
		printf("b is smaller than %u\n", border);
	}
	else {
		printf("b is bigger than %u\n", border);
	}
	if (v->c < border) {
		printf("c is smaller than %u\n", border);
	}
	else {
		printf("c is bigger than %u\n", border);
	}
	if (v->d < border) {
		printf("d is smaller than %u\n", border);
	}
	else {
		printf("G is bigger than %u\n", border);
	}

	func2(v);
}


int main(int argc, char* argv[])
{
	__asm {
		int 3
	};
	int a;
	char b;
	unsigned char c;
	unsigned int d;
	__try
	{
		if (argc <2) {
			a = 0; b = 0; c = 0; d = 0;
		}
		else if (argc<3) {
			a = 10; b = 10; c = 10; d = 10;
		}
		else {
			a = (int)*argv[0];
			b = *argv[1];
			c = (unsigned char)*argv[2];
			d = (unsigned int)*argv[3];
		}
		Variables v;
		v.a = a;
		v.b = b;
		v.c = c;
		v.d = d;
		func1(&v);
		return 0;
	}
	__except (EXCEPTION_INT_DIVIDE_BY_ZERO)
	{
		return 1;
	}
}

