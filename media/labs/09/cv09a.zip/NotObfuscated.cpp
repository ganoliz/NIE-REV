#include <Windows.h>
#include <tchar.h>
#include <CommCtrl.h>
#include "resource.h"
#include <string.h>

#pragma comment(linker, \
  "\"/manifestdependency:type='Win32' "\
  "name='Microsoft.Windows.Common-Controls' "\
  "version='6.0.0.0' "\
  "processorArchitecture='*' "\
  "publicKeyToken='6595b64144ccf1df' "\
  "language='*'\"")

#pragma comment(lib, "ComCtl32.lib")

bool comparePasswords(char* pass1, char* pass2,int size){
	for (int i = 0;i<size;i++){
		if (pass1[i] != pass2[i]){
			return false;
		}
	}
	return true;
}

INT_PTR CALLBACK DialogProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			SetDlgItemText(hDlg, IDC_EDIT1,L"Solve Me!");
		}
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			char userPassword[32];
			char* ourPassword;
			int bytesWritten;
			bytesWritten = GetDlgItemTextA(hDlg,IDC_EDIT1,userPassword,32);
			if (bytesWritten == 3){
				if (comparePasswords("REV",userPassword,bytesWritten)){
					MessageBox(hDlg,L"RIGHT!",L"RIGHT!",MB_OK);
					free(ourPassword);
					return TRUE;
				}
				free(ourPassword);
			}
			MessageBox(hDlg,L"Wrong",L"Wrong",MB_OK);
			return TRUE;
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hDlg);
		return TRUE; 

	case WM_DESTROY:
		PostQuitMessage(0);
		return TRUE;
	}
	return FALSE;
}

int WINAPI _tWinMain(HINSTANCE hInst, HINSTANCE h0, LPWSTR lpCmdLine, int nCmdShow)
{
  HWND hDlg;
  MSG msg;
  BOOL ret;

  InitCommonControls();
  hDlg = CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_DIALOG1), 0, DialogProc, 0);
  ShowWindow(hDlg, nCmdShow);

  while((ret = GetMessage(&msg, 0, 0, 0)) != 0) {
    if(ret == -1)
      return -1;

    if(!IsDialogMessage(hDlg, &msg)) {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }

  return 0;
}